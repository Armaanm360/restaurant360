
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 mt-4">
                <div class="card">
                    <div class="card-header">
                        <h3> All Pos Sales</h3>
                    </div>
                    <div class="card-body">
                        <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Invoice No</th>
                                    <th>Staff</th>
                                    <th>Client Phone</th>
                                    <th>By Sale</th>
                                    <th>Sales Date</th>
                                    <th>Net Total</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($invoice->invoice_no); ?></td>
                                        <td><?php echo e($invoice->staff_name); ?></td>
                                        <td><?php echo e($invoice->client_phone_number); ?></td>
                                        <td>Bank</td>
                                        <td><?php echo e($invoice->sales_date); ?></td>
                                        <td><?php echo e($invoice->grand_total); ?></td>
                                        <td>

                                            <?php if($invoice->invoice_return == 'NO'): ?>
                                                <a href="<?php echo e('invoice/' . $invoice->sale_id . '/' . 'edit'); ?>"
                                                    class="btn btn-sm btn-primary">Edit</a>
                                                <a href="<?php echo e('invoice-return-sale/' . $invoice->sale_id); ?>"
                                                    class="btn btn-sm btn-danger">Return</a>
                                            <?php endif; ?>

                                            
                                            <a href="<?php echo e('invoice/' . $invoice->sale_id); ?>"
                                                class="btn btn-sm btn-info">View</a>


                                            <button class="btn btn-sm btn-warning"
                                                onclick="deleteNow(<?php echo e($invoice->sale_id); ?>)">Delete</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function deleteNow(params) {
            var isConfirm = confirm('Are You Sure!');
            if (isConfirm) {
                $('.loader').show();
                $.ajax({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    },
                    type: 'DELETE',
                    url: "invoice" + '/' + params,
                    success: function(data) {
                        location.reload();
                    }
                }).done(function() {
                    $("#success_msg").html("Data Save Successfully");
                }).fail(function(data, textStatus, jqXHR) {
                    $('.loader').hide();
                    var json_data = JSON.parse(data.responseText);
                    $.each(json_data.errors, function(key, value) {
                        $("#" + key).after(
                            "<span class='error_msg' style='color: red;font-weigh: 600'>" +
                            value +
                            "</span>");
                    });
                });
            } else {
                $('.loader').hide();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/invoice/list_invoice.blade.php ENDPATH**/ ?>