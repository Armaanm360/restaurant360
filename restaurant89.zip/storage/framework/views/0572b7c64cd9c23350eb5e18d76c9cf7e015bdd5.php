
<?php $__env->startSection('content'); ?>
    <!-- Form section -->
    <!-- start: page toolbar -->
    <div class="page-toolbar px-xl-4 px-sm-2 px-0 py-3">
        <div class="container-fluid">
            <div class="row g-3 mb-3 align-items-center">
                <div class="col">
                    <ol class="breadcrumb bg-transparent mb-0">
                        <li class="breadcrumb-item"><a class="text-secondary" href="<?php echo e(url('/home')); ?>">Home</a></li>
                        <li class="breadcrumb-item"><a class="text-secondary" href="javascript:void()">Menu Item</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Create Menu Item</li>
                    </ol>
                </div>
                <div class="col text-md-end">
                    <a class="btn btn-primary" href="<?php echo e(url('products')); ?>"><i class="fa fa-list me-2"></i>List Menu
                        Item</a>
                    
                </div>
            </div>
        </div>
    </div>

    <!-- start: page body -->
    <div class="page-body px-xl-4 px-sm-2 px-0 py-lg-2 py-1 mt-0 mt-lg-3">
        <div class="container-fluid">
            <div class="row g-3">


                <!-- Form Validation -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="card-title mb-0">Create Menu Item</h6>
                        </div>
                        <div class="card-body">
                            <form class="row g-3 maskking-form" id="product_form">
                                <?php echo csrf_field(); ?>
                                <?php
                                    $date = date('y-m-d');
                                ?>
                                <input type="hidden" id="row" value="<?php echo e($row_count); ?>">
                                <input type="hidden" id="date" value="<?php echo e($date); ?>">
                                <div class="col-lg-4 col-md-6 col-sm-6">
                                    <span class="float-label">
                                        <select class="form-control form-control-lg custom-select" name="product_category">
                                            <option value="" disabled selected>
                                                <?php echo e(__('Select Menu')); ?>

                                            </option>
                                            <?php $__currentLoopData = $productCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->product_category_id); ?>">
                                                    <?php echo e($category->product_category_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <label class="form-label" for="TextInput">Product Menu</label>
                                    </span>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6">
                                    <span class="float-label">
                                        <input type="text" class="form-control form-control-lg" id="product_name"
                                            placeholder="Product Name" name="product_name">
                                        <label class="form-label" for="TextInput">Menu Item Name</label>
                                    </span>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6">
                                    <span class="float-label">
                                        <input type="text" class="form-control form-control-lg" id="product_entry_id"
                                            placeholder="Product Entry ID" name="product_entry_id" readonly>
                                        <label class="form-label" for="TextInput">Menu Item Entry ID</label>
                                    </span>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6">
                                    <span class="float-label">
                                        <input type="text" class="form-control form-control-lg" id="product_code"
                                            placeholder="Product Code" name="product_code" readonly>
                                        <label class="form-label" for="TextInput">Menu Item Code</label>
                                    </span>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6">
                                    <span class="float-label">
                                        <input type="text" class="form-control form-control-lg" id="product_retail_price"
                                            placeholder="Product Retail Price" name="product_retail_price">
                                        <label class="form-label" for="TextInput">Menu Item Retail Price</label>
                                    </span>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6">
                                    <span class="float-label">
                                        <input type="text" class="form-control form-control-lg"
                                            id="product_wholesale_price" placeholder="Product Wholesale Price"
                                            name="product_wholesale_price">
                                        <label class="form-label" for="TextInput">Menu Item Wholesale Price</label>
                                    </span>
                                </div>


                                <div class="col-lg-4 col-md-6 col-sm-6">
                                    <span class="float-label">
                                        <input class="form-control" type="file" id="file-input" name="product_image"
                                            accept=".jpg,.png,.jpeg">
                                        <label class="form-label" for="product">Menu Item Image</label>
                                    </span>
                                </div>
                                <div class="col-lg-4 col-md-6 col-sm-6">
                                    <div id='img_contain'>
                                        <img id="image-preview"
                                            align='middle'src="http://www.clker.com/cliparts/c/W/h/n/P/W/generic-image-file-icon-hi.png"
                                            alt="your image" title='' />
                                    </div>
                                </div>



                                <div class="col-12">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div> <!-- .row end -->

        </div>
    </div>
    <!-- end form section -->

    <script type="text/javascript">
        $('#product_name').keyup(function() {
            let rand = $('#product_name').val();
            let date1 = $('#date').val();
            let row_val = parseFloat($('#row').val()) || 0;
            let x = Math.floor((Math.random() * 100000) + 1);
            let newdate = date1.replace(/-|\//g, "");
            let variable = newdate + (row_val + 1);

            $('#product_entry_id').val(rand + x);
            $('#product_code').val(variable);

        });

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#image-preview').attr('src', e.target.result);
                    $('#image-preview').hide();
                    $('#image-preview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        $("#file-input").change(function() {
            readURL(this);
        });



        $("#product_form").submit(function(e) {
            e.preventDefault();
            $(this).find(':input[type=submit]').prop('disabled', true);
            $(".error_msg").html('');
            $('.loader').show();
            var data = new FormData($('#product_form')[0]);
            $.ajax({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                method: "POST",
                url: "<?php echo e(url('v1products')); ?>",
                data: data,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data, textStatus, jqXHR) {
                    $('.loader').hide();
                    window.location.href = "<?php echo e(url('products')); ?>";
                }
            }).done(function() {
                $("#success_msg").html("Data Save Successfully");
                $('.loader').hide();
                window.location.href = "<?php echo e(url('products')); ?>";
                // location.reload();
            }).fail(function(data, textStatus, jqXHR) {
                $("#loader").hide();
                $(this).find(':input[type=submit]').prop('enabled', true);
                var json_data = JSON.parse(data.responseText);
                $.each(json_data.errors, function(key, value) {
                    $("#" + key).after(
                        "<span class='error_msg' style='color: red;font-weigh: 600'>" + value +
                        "</span>");
                });
            });
        });

        var uploadField = document.getElementById("filecheck");

        uploadField.onchange = function() {
            if (this.files[0].size > 2097152) {
                alert("File is too big!");
                this.value = "";
            };
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\restaurant_version_merging\resources\views/pages/v1Products/create_products.blade.php ENDPATH**/ ?>