
<?php $__env->startSection('content'); ?>
    <?php $dashboard = app('App\Models\Dashboard\Dashboard'); ?>
    <?php
    $abc = $dashboard->get_today_profit();
    // echo '<pre>';print_r($abc);die;
    ?>


    <?php if(Auth::user()->role == 12): ?>
        <?php echo $__env->make('layouts.admin.dummy', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


    </script>

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\restaurant_user_wise\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>