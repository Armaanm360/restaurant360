
<?php $__env->startSection('content'); ?>
<div class="barcode" style="margin-left: 15%;margin-top: 3%;margin-bottom: 37%;">
    <p class="name"><?php echo e($product->product_name); ?></p>
    <p class="price">Price: <?php echo e($product->product_retail_price); ?></p>
    <?php echo DNS1D::getBarcodeHTML($product->product_entry_id, "C128",1.4,22); ?>

    <p class="pid"><?php echo e($product->product_entry_id); ?></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/restaurant360/crave.restaurant360.online/resources/views/pages/barcode/product_barcode.blade.php ENDPATH**/ ?>