
<?php $__env->startSection('content'); ?>
    <div class="col-md-12 mt-4">
        <div class="card">
            <div class="card-body">
                <table id="myTable" class="table display dataTable table-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>Sl</th>
                            <th>EXPENSE HEAD</th>
                            <th>EXPENSE SUBHEAD</th>
                            <th>EXPENSE AMOUNT</th>
                            <th>EXPENSE DATE</th>
                            <th>EXPENSE ACCOUNT</th>
                            <th>EXPENSE ACCOUNT LAST BAL.</th>
                            <th>ACTION</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $expense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="sorting"><?php echo e($loop->index + 1); ?></td>
                                <td><?php echo e(getExpenseHead($expense->expense_head_id)); ?></td>
                                <td><?php echo e(getExpenseSubHead($expense->expense_sub_head_id)); ?></td>
                                <td><?php echo e($expense->expense_amount); ?></td>
                                <td>2011/04/25</td>
                                <td><?php echo e(getPaymentType($expense->expense_account) . '(' . $expense->expense_account . ')'); ?></td>
                                <td class="dt-body-right">
                                    <?php echo e(get_acoount_current_balance_by_account_id($expense->expense_account)); ?></td>
                                <td class="dt-body-right">$320,800</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppnew\htdocs\dokani-v4\resources\views/pages/expenses/list_expenses.blade.php ENDPATH**/ ?>