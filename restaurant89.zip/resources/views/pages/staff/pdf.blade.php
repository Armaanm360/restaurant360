<!DOCTYPE html>
<html>
<head>
	<title>Staff</title>
</head>
<body>staff_entry_id
 <h1>name:{{$data->staff_name}}</h1>
  <h2>entry_id:{{$data->staff_entry_id}}</h2>
       
</body>
</html>