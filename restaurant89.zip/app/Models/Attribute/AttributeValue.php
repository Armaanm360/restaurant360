<?php

namespace App\Models\Attribute;

use Illuminate\Database\Eloquent\Model;

class AttributeValue extends Model
{
    //
}
