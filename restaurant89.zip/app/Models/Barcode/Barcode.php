<?php

namespace App\Models\Barcode;

use Illuminate\Database\Eloquent\Model;

class Barcode extends Model
{
    
}